CrimeData Plugin

Description:
-------------
CrimeData is a plugin for GTA 5 using the LSPDFR framework. It provides real-time crime reporting functionality and allows users to submit arrest reports directly within the game environment.

Features:
-------------
- Real-time crime reporting: Users can report crimes such as traffic violations, assaults, robberies, and homicides.
- Arrest reporting: Automatically prompts users to fill out arrest reports when they arrest someone in-game.
- Native GTA 5 UI: Utilizes the native GTA 5 UI elements for a seamless user experience.

Installation:
-------------
1. Make sure you have RagePluginHook installed and set up correctly in your GTA 5 directory.
2. Compile the CrimeDataPlugin.cs source code file into a DLL.
3. Place the compiled DLL file in the "Plugins" folder within your GTA 5 directory.

Usage:
-------------
1. Launch GTA 5 with RagePluginHook.
2. In-game, the CrimeData plugin will provide real-time crime reporting functionality.
3. When you arrest someone, the plugin will automatically prompt you to fill out an arrest report using the native GTA 5 UI.

Contributing:
-------------
This project is open-source, and contributions are welcome! If you have any suggestions, bug reports, or feature requests, please create an issue or pull request on the GitHub repository.

License:
-------------
This project is licensed under the [insert license name] license. See the LICENSE file for details.

Author:
-------------
